var searchData=
[
  ['yosemite_20support_20is_20deprecated_0',['OS X Yosemite support is deprecated',['../news.html#yosemite_deprecated',1,'']]]
];
